# server.py

# a. Import necessary libraries and function
from flask import Flask, render_template, request
from SentimentAnalysis.sentiment_analysis import sentiment_analyzer

# b. Initialize Flask app
app = Flask("Sentiment Analyzer")

# c. Define route for sentiment analysis API
@app.route("/sentimentAnalyzer")
def sent_analyzer():
    # Retrieve text input from the query
    text_to_analyze = request.args.get('textToAnalyze')

    # Call the Watson sentiment analyzer
    response = sentiment_analyzer(text_to_analyze)

    label = response['label']
    score = response['score']

    # Handle invalid input or model error
    if label is None:
        return "Invalid input! Try again."
    else:
        return f"The given text has been identified as {label.split('_')[1]} with a score of {score}."

# d. Define route for rendering the HTML page
@app.route("/")
def render_index_page():
    return render_template('index.html')

# e. Run the app
if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
