# SentimentAnalysis/sentiment_analysis.py

import requests
import json

def sentiment_analyzer(text_to_analyse):
    # Watson NLP API endpoint
    url = 'https://sn-watson-sentiment-bert.labs.skills.network/v1/watson.runtime.nlp.v1/NlpService/SentimentPredict'

    # Input payload
    myobj = { "raw_document": { "text": text_to_analyse } }

    # Request headers
    header = { "grpc-metadata-mm-model-id": "sentiment_aggregated-bert-workflow_lang_multi_stock" }

    # Send request
    response = requests.post(url, json=myobj, headers=header)

    # Attempt to parse the response
    formatted_response = json.loads(response.text)

    # Case: Success
    if response.status_code == 200:
        label = formatted_response['documentSentiment']['label']
        score = formatted_response['documentSentiment']['score']

    # Case: Server error (invalid input or model failure)
    elif response.status_code == 500:
        label = None
        score = None

    return { "label": label, "score": score }
